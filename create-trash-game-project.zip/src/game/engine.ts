import {
  GY,
  H,
  W,
  buildLevel,
  overlap,
} from './levels';
import type { Ent, Enemy, Level, Rect } from './levels';
import {
  drawBackground,
  drawCage,
  drawChick,
  drawCrate,
  drawDenchik,
  drawEnemy,
  drawGround,
  drawItem,
  drawMoonStone,
  drawPlat,
  drawPuddle,
  drawSlime,
  drawToilet,
  heart,
  text,
} from './art';

const GRAV = 0.6;
const MAX_HP = 5;
const START_LIVES = 3;
const FART_COST = 34;

type State = 'title' | 'story' | 'play' | 'levelclear' | 'gameover' | 'win';
type Action = 'left' | 'right' | 'jump' | 'shoot' | 'fart';

interface Player extends Ent {
  dir: number;
  hp: number;
  inv: number;
  jumpBuf: number;
  coyote: number;
  shootCd: number;
  shootAnim: number;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  color: string;
  size: number;
  grav: number;
}
interface Proj {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  r: number;
  hostile: boolean;
}
interface Cloud {
  x: number;
  y: number;
  r: number;
  life: number;
  max: number;
}

function move(e: Ent, solids: Rect[], oneway: Rect[]) {
  let wall = false;
  e.x += e.vx;
  for (const s of solids) {
    if (overlap(e, s)) {
      if (e.vx > 0) e.x = s.x - e.w;
      else if (e.vx < 0) e.x = s.x + s.w;
      else continue;
      wall = true;
    }
  }
  const prevBottom = e.y + e.h;
  e.vy = Math.min(e.vy + GRAV, 16);
  e.y += e.vy;
  e.onGround = false;
  const vy = e.vy;
  for (const s of solids) {
    if (overlap(e, s)) {
      if (vy > 0) {
        e.y = s.y - e.h;
        e.onGround = true;
      } else if (vy < 0) {
        e.y = s.y + s.h;
      }
      e.vy = 0;
    }
  }
  if (e.vy >= 0) {
    for (const p of oneway) {
      if (overlap(e, p) && prevBottom <= p.y + 1) {
        e.y = p.y - e.h;
        e.vy = 0;
        e.onGround = true;
      }
    }
  }
  return wall;
}

function pointSolid(solids: Rect[], x: number, y: number) {
  return solids.some((s) => x >= s.x && x <= s.x + s.w && y >= s.y && y <= s.y + s.h);
}

export class Game {
  ctx: CanvasRenderingContext2D;
  canvas: HTMLCanvasElement;
  state: State = 'title';
  muted = false;
  frame = 0;
  level = 0;
  lv: Level;
  lives = START_LIVES;
  score = 0;
  seeds = 0;
  ammo = 12;
  gas = 100;
  p: Player;
  cp = 80;
  camX = 0;
  shake = 0;
  introT = 0;
  stateT = 0;
  particles: Particle[] = [];
  projs: Proj[] = [];
  clouds: Cloud[] = [];
  arenaActive = false;
  bossDead = false;
  spawnT = 0;
  regenT = 0;
  held: Record<Action, boolean> = { left: false, right: false, jump: false, shoot: false, fart: false };
  pressed = { jump: false, shoot: false, fart: false, start: false };
  actx: AudioContext | null = null;
  raf = 0;
  last = 0;
  acc = 0;
  disposed = false;
  msg = '';
  msgT = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.lv = buildLevel(0);
    this.p = this.newPlayer();
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.actx?.close().catch(() => undefined);
  }

  newPlayer(): Player {
    return {
      x: 80,
      y: GY - 52,
      w: 28,
      h: 52,
      vx: 0,
      vy: 0,
      onGround: false,
      dir: 1,
      hp: MAX_HP,
      inv: 0,
      jumpBuf: 0,
      coyote: 0,
      shootCd: 0,
      shootAnim: 0,
    };
  }

  /* ---------------- input ---------------- */
  keyAction(code: string): Action | null {
    switch (code) {
      case 'ArrowLeft':
      case 'KeyA':
        return 'left';
      case 'ArrowRight':
      case 'KeyD':
        return 'right';
      case 'ArrowUp':
      case 'KeyW':
      case 'Space':
        return 'jump';
      case 'KeyX':
      case 'KeyJ':
        return 'shoot';
      case 'KeyZ':
      case 'KeyK':
      case 'ArrowDown':
        return 'fart';
      default:
        return null;
    }
  }

  onKeyDown = (e: KeyboardEvent) => {
    const a = this.keyAction(e.code);
    if (a || e.code === 'Enter') e.preventDefault();
    this.ensureAudio();
    if (e.code === 'KeyM' && !e.repeat) this.muted = !this.muted;
    if (e.repeat) return;
    if (a) this.setHeld(a, true);
    if (e.code === 'Enter') this.pressed.start = true;
  };

  onKeyUp = (e: KeyboardEvent) => {
    const a = this.keyAction(e.code);
    if (a) this.held[a] = false;
  };

  setHeld(a: Action, v: boolean) {
    this.ensureAudio();
    this.held[a] = v;
    if (v) {
      if (a === 'jump') {
        this.pressed.jump = true;
        this.pressed.start = true;
      } else if (a === 'shoot') this.pressed.shoot = true;
      else if (a === 'fart') this.pressed.fart = true;
    }
  }

  tap() {
    this.ensureAudio();
    this.pressed.start = true;
  }

  /* ---------------- audio ---------------- */
  ensureAudio() {
    if (!this.actx) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.actx = new AC();
      } catch {
        this.actx = null;
      }
    }
    if (this.actx && this.actx.state === 'suspended') this.actx.resume().catch(() => undefined);
  }

  tone(type: OscillatorType, f0: number, f1: number, dur: number, vol = 0.12, delay = 0) {
    if (this.muted || !this.actx) return;
    const a = this.actx;
    const t = a.currentTime + delay;
    const o = a.createOscillator();
    const g = a.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(a.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  fartSound(big = false) {
    if (this.muted || !this.actx) return;
    const a = this.actx;
    const t = a.currentTime;
    const o = a.createOscillator();
    const g = a.createGain();
    o.type = 'sawtooth';
    const dur = big ? 0.7 : 0.42;
    for (let i = 0; i < 12; i++) {
      o.frequency.setValueAtTime(55 + Math.random() * 50 - i * 2, t + (i * dur) / 12);
    }
    g.gain.setValueAtTime(0.22, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(a.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  /* ---------------- flow ---------------- */
  resetGame() {
    this.level = 0;
    this.lives = START_LIVES;
    this.score = 0;
    this.seeds = 0;
    this.ammo = 12;
    this.gas = 100;
  }

  startLevel(i: number) {
    this.level = i;
    this.lv = buildLevel(i);
    this.p = this.newPlayer();
    this.cp = 80;
    this.camX = 0;
    this.particles = [];
    this.projs = [];
    this.clouds = [];
    this.arenaActive = false;
    this.bossDead = false;
    this.spawnT = 0;
    this.introT = 170;
    this.state = 'play';
    this.gas = Math.max(this.gas, 70);
    this.ammo = Math.max(this.ammo, 10);
  }

  setState(s: State) {
    this.state = s;
    this.stateT = 0;
  }

  say(m: string) {
    this.msg = m;
    this.msgT = 120;
  }

  burst(x: number, y: number, color: string, n: number, speed = 3, size = 4, grav = 0.15) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = Math.random() * speed;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - speed * 0.3,
        life: 25 + Math.random() * 25,
        max: 50,
        color,
        size: size * (0.5 + Math.random()),
        grav,
      });
    }
  }

  hurt(dmg: number, fromX: number) {
    const p = this.p;
    if (p.inv > 0 || this.state !== 'play') return;
    p.hp -= dmg;
    p.inv = 90;
    p.vy = -6;
    p.vx = p.x + p.w / 2 > fromX ? 6 : -6;
    this.shake = 12;
    this.tone('square', 300, 80, 0.3, 0.15);
    this.burst(p.x + 14, p.y + 20, '#e63946', 10, 4);
    if (p.hp <= 0) this.die();
  }

  die() {
    this.lives--;
    this.tone('sawtooth', 400, 40, 0.8, 0.2);
    if (this.lives <= 0) {
      this.setState('gameover');
      return;
    }
    this.respawn(true);
  }

  respawn(full: boolean) {
    const p = this.p;
    if (full) p.hp = MAX_HP;
    p.x = this.cp;
    p.y = GY - p.h - 4;
    p.vx = 0;
    p.vy = 0;
    p.inv = 120;
    this.projs = this.projs.filter((q) => !q.hostile);
  }

  /* ---------------- main loop ---------------- */
  loop = (now: number) => {
    if (this.disposed) return;
    const dt = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    this.acc += dt;
    while (this.acc >= 1 / 60) {
      this.update();
      this.acc -= 1 / 60;
    }
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  };

  update() {
    this.frame++;
    this.stateT++;
    const pr = this.pressed;
    switch (this.state) {
      case 'title':
        if (pr.start) {
          this.resetGame();
          this.setState('story');
          this.tone('square', 200, 600, 0.2);
        }
        break;
      case 'story':
        if (pr.start && this.stateT > 20) this.startLevel(0);
        break;
      case 'play':
        this.updatePlay();
        break;
      case 'levelclear':
        if (pr.start && this.stateT > 30) {
          this.startLevel(this.level + 1);
        }
        break;
      case 'gameover':
      case 'win':
        if (pr.start && this.stateT > 60) {
          this.lv = buildLevel(0);
          this.setState('title');
        }
        break;
    }
    pr.jump = pr.shoot = pr.fart = pr.start = false;
    if (this.shake > 0) this.shake--;
    if (this.msgT > 0) this.msgT--;
    this.updateParticles();
  }

  updateParticles() {
    for (const q of this.particles) {
      q.x += q.vx;
      q.y += q.vy;
      q.vy += q.grav;
      q.life--;
    }
    this.particles = this.particles.filter((q) => q.life > 0);
  }

  updatePlay() {
    const lv = this.lv;
    const p = this.p;
    const k = this.held;
    const pr = this.pressed;
    if (this.introT > 0) this.introT--;

    /* --- player --- */
    let ax = 0;
    if (k.left) ax -= 1;
    if (k.right) ax += 1;
    if (ax !== 0) {
      p.vx += ax * 0.9;
      p.vx = Math.max(-4.4, Math.min(4.4, p.vx));
      p.dir = ax;
    } else {
      p.vx *= 0.8;
      if (Math.abs(p.vx) < 0.2) p.vx = 0;
    }

    if (pr.jump) p.jumpBuf = 7;
    if (p.jumpBuf > 0) p.jumpBuf--;
    if (p.onGround) p.coyote = 6;
    else if (p.coyote > 0) p.coyote--;
    if (p.jumpBuf > 0 && p.coyote > 0) {
      p.vy = -12.6;
      p.jumpBuf = 0;
      p.coyote = 0;
      this.tone('square', 260, 520, 0.12, 0.07);
    }
    if (!k.jump && p.vy < -4.5) p.vy = -4.5;

    // snot
    if (p.shootCd > 0) p.shootCd--;
    if (p.shootAnim > 0) p.shootAnim--;
    if ((pr.shoot || k.shoot) && p.shootCd <= 0 && p.hp > 0) {
      if (this.ammo > 0) {
        this.ammo--;
        p.shootCd = 14;
        p.shootAnim = 8;
        this.projs.push({
          x: p.x + p.w / 2 + p.dir * 18,
          y: p.y + 22,
          vx: p.dir * 9 + p.vx * 0.3,
          vy: -1,
          life: 70,
          r: 6,
          hostile: false,
        });
        this.tone('triangle', 900, 300, 0.12, 0.1);
      } else {
        p.shootCd = 20;
        this.tone('square', 120, 80, 0.1, 0.06);
        this.say('Сопли кончились! Ищи зелёные баночки');
      }
    }
    this.regenT++;
    if (this.regenT > 200) {
      this.regenT = 0;
      if (this.ammo < 3) this.ammo++;
    }

    // fart
    this.gas = Math.min(100, this.gas + 0.07);
    if (pr.fart) {
      if (this.gas >= FART_COST) {
        this.gas -= FART_COST;
        this.clouds.push({ x: p.x + p.w / 2 - p.dir * 16, y: p.y + p.h - 10, r: 18, life: 55, max: 55 });
        if (!p.onGround) p.vy = Math.min(p.vy, 0) - 9.5;
        this.fartSound();
        this.shake = Math.max(this.shake, 4);
        this.burst(p.x + p.w / 2 - p.dir * 16, p.y + p.h - 8, '#a7e22e', 14, 3, 7, -0.02);
      } else {
        this.say('Газу нет! Жри фасоль!');
        this.tone('square', 100, 60, 0.1, 0.06);
      }
    }

    move(p, lv.solids, lv.plats);
    if (p.x < 0) p.x = 0;
    if (p.x > lv.width - p.w) p.x = lv.width - p.w;
    if (p.inv > 0) p.inv--;

    // checkpoint tracking
    if (p.onGround) {
      for (const g of lv.grounds) {
        if (p.x > g.x + 40 && p.x + p.w < g.x + g.w - 40 && Math.abs(p.y + p.h - GY) < 2) this.cp = p.x;
      }
    }

    // boss arena
    if (lv.boss && !this.bossDead && !this.arenaActive && p.x > lv.arenaLeft + 120) {
      this.arenaActive = true;
      lv.solids.push({ x: lv.arenaLeft - 30, y: -800, w: 30, h: 1800 });
      this.say('УНИТАЗИЛЛА: «Я СМОЮ ТЕБЯ, ДЕНЧИК!»');
      this.shake = 20;
      this.tone('sawtooth', 80, 40, 0.8, 0.2);
    }
    if (this.arenaActive && p.x < lv.arenaLeft) p.x = lv.arenaLeft;

    // fall in slime
    if (p.y > GY + 110) {
      p.hp--;
      this.burst(p.x + 14, GY + 70, '#9bff3d', 20, 5, 6);
      this.tone('sine', 500, 100, 0.4, 0.15);
      this.shake = 12;
      if (p.hp <= 0) this.die();
      else this.respawn(false);
    }

    /* --- items --- */
    for (const it of lv.items) {
      if (it.taken || !overlap(p, it)) continue;
      it.taken = true;
      if (it.kind === 'seed') {
        this.seeds++;
        this.score += 10;
        this.tone('square', 900, 1300, 0.06, 0.05);
        if (this.seeds % 50 === 0) {
          this.lives++;
          this.say('50 СЕМЕЧЕК = +1 ЖИЗНЬ!');
        }
      } else if (it.kind === 'shawarma') {
        p.hp = Math.min(MAX_HP, p.hp + 2);
        this.score += 50;
        this.say('Шаурма! +2 сердца (а вдруг из кошки?)');
        this.tone('square', 400, 800, 0.2, 0.08);
        this.tone('square', 600, 1000, 0.2, 0.08, 0.1);
      } else if (it.kind === 'beans') {
        this.gas = Math.min(100, this.gas + 60);
        this.score += 25;
        this.say('Фасоль! Бак заправлен газом');
        this.tone('square', 300, 600, 0.15, 0.08);
      } else {
        this.ammo = Math.min(30, this.ammo + 8);
        this.score += 25;
        this.say('Сопли! +8 зарядов');
        this.tone('square', 500, 900, 0.15, 0.08);
      }
    }

    // boss-fight supply drops
    if (this.arenaActive && !this.bossDead) {
      this.spawnT++;
      if (this.spawnT > 480) {
        this.spawnT = 0;
        const kind = Math.random() < 0.5 ? 'snot' : 'beans';
        lv.items.push({
          x: lv.arenaLeft + 80 + Math.random() * (lv.width - lv.arenaLeft - 300),
          y: GY - 200,
          w: 20,
          h: 20,
          kind,
          t: -1000,
          taken: false,
        });
      }
      // dropped items fall to ground
    }
    for (const it of lv.items) {
      if (!it.taken && it.t < 0 && it.y < GY - 30) it.y += 2;
    }

    /* --- puddles --- */
    for (const pu of lv.puddles) {
      if (overlap(p, { x: pu.x + 8, y: pu.y, w: pu.w - 16, h: pu.h })) this.hurt(1, pu.x + pu.w / 2);
    }

    /* --- projectiles --- */
    for (const q of this.projs) {
      q.x += q.vx;
      q.y += q.vy;
      q.vy += q.hostile ? 0.35 : 0.12;
      q.life--;
      if (pointSolid(lv.solids, q.x, q.y)) {
        q.life = 0;
        this.burst(q.x, q.y, q.hostile ? '#6b4423' : '#9bff3d', 6, 2.5, 4);
        continue;
      }
      if (q.hostile) {
        if (overlap(p, { x: q.x - q.r, y: q.y - q.r, w: q.r * 2, h: q.r * 2 })) {
          q.life = 0;
          this.burst(q.x, q.y, '#6b4423', 8, 3, 5);
          this.hurt(1, q.x);
        }
      } else {
        for (const e of lv.enemies) {
          if (e.dead) continue;
          if (overlap(e, { x: q.x - q.r, y: q.y - q.r, w: q.r * 2, h: q.r * 2 })) {
            q.life = 0;
            this.burst(q.x, q.y, '#9bff3d', 8, 3, 5);
            this.damageEnemy(e, 1);
            break;
          }
        }
      }
    }
    this.projs = this.projs.filter((q) => q.life > 0);

    /* --- clouds --- */
    for (const c of this.clouds) {
      c.life--;
      c.r = Math.min(78, c.r + 1.6);
      c.y -= 0.2;
      if (this.frame % 3 === 0)
        this.particles.push({
          x: c.x + (Math.random() - 0.5) * c.r,
          y: c.y + (Math.random() - 0.5) * c.r * 0.6,
          vx: (Math.random() - 0.5) * 0.8,
          vy: -0.5 - Math.random() * 0.5,
          life: 25,
          max: 25,
          color: 'rgba(167,226,46,.6)',
          size: 8 + Math.random() * 6,
          grav: -0.01,
        });
      for (const q of this.projs) {
        if (q.hostile && Math.hypot(q.x - c.x, q.y - c.y) < c.r) q.life = 0;
      }
      for (const e of lv.enemies) {
        if (e.dead) continue;
        const ex = Math.max(e.x, Math.min(c.x, e.x + e.w));
        const ey = Math.max(e.y, Math.min(c.y, e.y + e.h));
        if (Math.hypot(ex - c.x, ey - c.y) < c.r && e.hitCd <= 0) {
          e.hitCd = e.kind === 'boss' ? 25 : 18;
          this.damageEnemy(e, 1);
        }
      }
    }
    this.clouds = this.clouds.filter((c) => c.life > 0);

    /* --- enemies --- */
    for (const e of lv.enemies) {
      if (e.dead) continue;
      this.updateEnemy(e);
    }
    lv.enemies = lv.enemies.filter((e) => !e.dead);

    /* --- exit --- */
    if (lv.boss) {
      if (this.bossDead && overlap(p, lv.exit)) {
        this.score += p.hp * 200 + 5000;
        this.setState('win');
        this.tone('square', 523, 523, 0.15, 0.1);
        this.tone('square', 659, 659, 0.15, 0.1, 0.15);
        this.tone('square', 784, 784, 0.15, 0.1, 0.3);
        this.tone('square', 1046, 1046, 0.5, 0.1, 0.45);
        return;
      }
    } else if (overlap(p, lv.exit)) {
      this.score += p.hp * 100 + 500;
      this.setState('levelclear');
      this.tone('square', 523, 523, 0.12, 0.1);
      this.tone('square', 659, 659, 0.12, 0.1, 0.12);
      this.tone('square', 784, 784, 0.3, 0.1, 0.24);
      this.fartSound(true);
      return;
    }

    /* --- camera --- */
    const minCam = this.arenaActive ? lv.arenaLeft : 0;
    const target = Math.max(minCam, Math.min(lv.width - W, p.x - W * 0.4));
    this.camX += (target - this.camX) * 0.12;
  }

  damageEnemy(e: Enemy, n: number) {
    e.hp -= n;
    e.flash = 6;
    this.tone('square', 220, 110, 0.08, 0.08);
    if (e.hp <= 0) {
      e.dead = true;
      this.score += e.score;
      const cx = e.x + e.w / 2;
      const cy = e.y + e.h / 2;
      if (e.kind === 'boss') {
        this.bossDead = true;
        this.burst(cx, cy, '#f1f3f5', 50, 9, 9);
        this.burst(cx, cy, '#7a4a1a', 50, 8, 8);
        this.burst(cx, cy, '#9bff3d', 40, 7, 7);
        this.shake = 40;
        this.projs = this.projs.filter((q) => !q.hostile);
        this.fartSound(true);
        this.say('УНИТАЗИЛЛА СЛИТ! Освободи Чикетку!');
        this.lv.items.push({ x: cx, y: GY - 30, w: 20, h: 20, kind: 'shawarma', t: 0, taken: false });
      } else {
        this.burst(cx, cy, e.kind === 'fly' ? '#556b2f' : e.kind === 'bin' ? '#8a9a9a' : '#7d7d8c', 14, 4, 5);
        this.burst(cx, cy, '#9bff3d', 6, 3, 4);
        if (Math.random() < 0.5)
          for (let i = 0; i < 3; i++)
            this.lv.items.push({ x: cx - 30 + i * 22, y: e.y - 20, w: 20, h: 20, kind: 'seed', t: i * 10, taken: false });
        this.tone('sawtooth', 300, 60, 0.25, 0.1);
      }
    }
  }

  updateEnemy(e: Enemy) {
    const lv = this.lv;
    const p = this.p;
    if (e.hitCd > 0) e.hitCd--;
    if (e.flash > 0) e.flash--;
    e.t++;
    const dx = p.x + p.w / 2 - (e.x + e.w / 2);

    if (e.kind === 'rat') {
      e.vx = e.dir * 1.3;
      if (Math.abs(e.x - e.baseX) > 170) e.dir = e.x > e.baseX ? -1 : 1;
      const wall = move(e, lv.solids, []);
      const frontX = e.dir > 0 ? e.x + e.w + 4 : e.x - 4;
      if (wall || (e.onGround && !pointSolid(lv.solids, frontX, e.y + e.h + 6))) e.dir *= -1;
    } else if (e.kind === 'fly') {
      if (Math.abs(dx) < 450) {
        e.vx += Math.sign(dx) * 0.06;
        e.vx = Math.max(-1.8, Math.min(1.8, e.vx));
      } else e.vx *= 0.95;
      e.x += e.vx;
      const targetY = Math.abs(dx) < 300 ? Math.min(GY - 40, Math.max(GY - 170, p.y - 10)) : e.baseY;
      e.baseY += (targetY - e.baseY) * 0.01;
      e.y = e.baseY + Math.sin(e.t * 0.08) * 28;
    } else if (e.kind === 'bin') {
      if (e.onGround) {
        e.vx = 0;
        if (e.t % 100 === 0 && Math.abs(dx) < 380) {
          e.vy = -11;
          e.vx = Math.sign(dx) * 2.6;
        }
      }
      move(e, lv.solids, []);
    } else {
      this.updateBoss(e, dx);
    }

    if (e.dead) return;

    // contact with player
    if (this.state !== 'play') return;
    const hb = { x: e.x + 4, y: e.y + 2, w: e.w - 8, h: e.h - 2 };
    if (overlap(p, hb)) {
      const prevBottom = p.y + p.h - p.vy;
      if (p.vy > 0 && prevBottom <= e.y + 14 && e.hitCd <= 0) {
        e.hitCd = e.kind === 'boss' ? 25 : 6;
        p.vy = this.held.jump ? -13 : -9;
        this.damageEnemy(e, e.kind === 'boss' ? 3 : 2);
        this.burst(p.x + 14, p.y + p.h, '#fff', 6, 3, 3);
      } else {
        this.hurt(1, e.x + e.w / 2);
      }
    }
  }

  updateBoss(b: Enemy, dx: number) {
    const lv = this.lv;
    if (!this.arenaActive) return;
    const enraged = b.hp < b.maxHp / 2;
    b.dir = dx > 0 ? 1 : -1;
    const wasAir = !b.onGround;
    if (b.onGround) {
      b.vx = b.dir * (enraged ? 2.2 : 1.3);
      if (b.t % (enraged ? 100 : 150) === 0) {
        b.vy = -15;
        b.vx = b.dir * (enraged ? 5.5 : 4);
        this.tone('sawtooth', 120, 60, 0.3, 0.12);
      }
    }
    move(b, lv.solids, []);
    if (wasAir && b.onGround) {
      this.shake = 14;
      this.burst(b.x + b.w / 2, b.y + b.h, '#cfcfe0', 16, 5, 6);
      this.tone('sawtooth', 70, 30, 0.4, 0.2);
    }
    b.x = Math.max(lv.arenaLeft + 10, Math.min(lv.width - b.w - 10, b.x));
    if (b.t % (enraged ? 70 : 105) === 50) {
      const n = enraged ? 2 : 1;
      for (let i = 0; i < n; i++)
        this.projs.push({
          x: b.x + b.w / 2,
          y: b.y + 20,
          vx: b.dir * (2.5 + Math.random() * 4.5),
          vy: -9 - Math.random() * 4,
          life: 200,
          r: 9,
          hostile: true,
        });
      this.tone('square', 200, 90, 0.2, 0.1);
    }
  }

  /* ---------------- rendering ---------------- */
  render() {
    const c = this.ctx;
    c.save();
    c.clearRect(0, 0, W, H);
    switch (this.state) {
      case 'title':
        this.renderTitle(c);
        break;
      case 'story':
        this.renderStory(c);
        break;
      default:
        this.renderWorld(c);
        if (this.state === 'play') this.renderHud(c);
        if (this.state === 'levelclear') this.renderClear(c);
        if (this.state === 'gameover') this.renderGameOver(c);
        if (this.state === 'win') this.renderWin(c);
    }
    c.restore();
  }

  renderWorld(c: CanvasRenderingContext2D) {
    const lv = this.lv;
    const p = this.p;
    const cam0 = this.camX;
    drawBackground(c, lv.theme, cam0, this.frame);
    drawSlime(c, lv.theme, this.frame);
    c.save();
    if (this.shake > 0) c.translate((Math.random() - 0.5) * this.shake * 0.8, (Math.random() - 0.5) * this.shake * 0.8);
    const cam = cam0;
    for (const g of lv.grounds) drawGround(c, lv.theme, g.x, g.w, cam);
    c.save();
    c.translate(-cam, 0);
    for (let i = lv.grounds.length; i < lv.solids.length; i++) {
      const s = lv.solids[i];
      if (s.h > 100) continue;
      if (s.x + s.w < cam || s.x > cam + W) continue;
      drawCrate(c, lv.theme, s.x, s.y, s.w, s.h);
    }
    for (const pl of lv.plats) if (pl.x + pl.w > cam && pl.x < cam + W) drawPlat(c, lv.theme, pl.x, pl.y, pl.w);
    for (const pu of lv.puddles) if (pu.x + pu.w > cam && pu.x < cam + W) drawPuddle(c, pu.x, pu.y, pu.w, this.frame);

    // exit
    if (lv.boss) {
      drawCage(c, lv.width - 150, GY - 120, this.bossDead, this.frame);
    } else {
      drawToilet(c, lv.exit.x, lv.exit.y, this.frame);
      c.fillStyle = '#fff';
      text(c, 'СМЫТЬСЯ', lv.exit.x + 32, lv.exit.y - 40, 16, '#ffd60a');
    }

    for (const it of lv.items) if (!it.taken && it.x + 20 > cam && it.x < cam + W) drawItem(c, it, this.frame);

    for (const e of lv.enemies) {
      if (e.x + e.w < cam - 50 || e.x > cam + W + 50) continue;
      drawEnemy(c, e, this.frame, p.x);
    }

    // projectiles
    for (const q of this.projs) {
      if (q.hostile) {
        c.fillStyle = '#6b4423';
        c.beginPath();
        c.arc(q.x, q.y, q.r, 0, Math.PI * 2);
        c.fill();
        c.fillStyle = '#8b5a2b';
        c.beginPath();
        c.arc(q.x - 2, q.y - 3, q.r * 0.5, 0, Math.PI * 2);
        c.fill();
      } else {
        c.fillStyle = '#9bff3d';
        c.beginPath();
        c.ellipse(q.x, q.y, q.r + 2, q.r - 1, Math.atan2(q.vy, q.vx), 0, Math.PI * 2);
        c.fill();
        c.fillStyle = 'rgba(255,255,255,.7)';
        c.beginPath();
        c.arc(q.x - 1, q.y - 2, 2, 0, Math.PI * 2);
        c.fill();
      }
    }

    // player
    if (!(p.inv > 0 && Math.floor(p.inv / 4) % 2 === 0) || this.state !== 'play') {
      drawDenchik(c, p.x, p.y, p.dir, p.vx, p.vy, p.onGround, this.frame, p.shootAnim > 0);
    }

    // clouds
    for (const cl of this.clouds) {
      const a = Math.min(1, cl.life / 25) * 0.5;
      c.fillStyle = `rgba(167,226,46,${a})`;
      c.beginPath();
      c.arc(cl.x, cl.y, cl.r, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = `rgba(110,170,20,${a})`;
      c.beginPath();
      c.arc(cl.x - cl.r * 0.3, cl.y + cl.r * 0.1, cl.r * 0.6, 0, Math.PI * 2);
      c.fill();
    }

    for (const q of this.particles) {
      c.globalAlpha = Math.max(0, Math.min(1, q.life / 20));
      c.fillStyle = q.color;
      c.beginPath();
      c.arc(q.x, q.y, q.size, 0, Math.PI * 2);
      c.fill();
    }
    c.globalAlpha = 1;
    c.restore();
    c.restore();
  }

  renderHud(c: CanvasRenderingContext2D) {
    const p = this.p;
    // panel
    c.fillStyle = 'rgba(0,0,0,.45)';
    c.beginPath();
    c.roundRect(10, 10, 300, 82, 10);
    c.fill();
    for (let i = 0; i < MAX_HP; i++) heart(c, 30 + i * 28, 16, 22, i < p.hp ? '#ff4d6d' : '#4a2a33');
    text(c, 'ЖИЗНИ ×' + this.lives, 224, 36, 16, '#ffd60a', '#000', 'left');
    // bars
    c.font = 'bold 11px sans-serif';
    c.fillStyle = '#fff';
    c.textAlign = 'left';
    c.fillText('ГАЗ', 18, 62);
    c.fillStyle = '#222';
    c.fillRect(50, 53, 120, 10);
    c.fillStyle = this.gas >= FART_COST ? '#a7e22e' : '#e63946';
    c.fillRect(50, 53, 1.2 * this.gas, 10);
    c.fillStyle = 'rgba(255,255,255,.7)';
    c.fillRect(50 + 1.2 * FART_COST, 51, 2, 14);
    c.fillStyle = '#fff';
    c.fillText('СОПЛИ', 18, 80);
    c.fillStyle = '#9bff3d';
    for (let i = 0; i < Math.min(this.ammo, 30); i++) c.fillRect(64 + i * 3.6, 72, 2.6, 9);
    text(c, `🌻 ${this.seeds}`, 224, 66, 16, '#fff', '#000', 'left');

    // score
    c.fillStyle = 'rgba(0,0,0,.45)';
    c.beginPath();
    c.roundRect(W - 230, 10, 220, 46, 10);
    c.fill();
    text(c, String(this.score).padStart(7, '0'), W - 20, 44, 30, '#ffd60a', '#000', 'right');
    text(c, this.lv.name, W - 20, 76, 14, '#fff', '#000', 'right');

    // boss bar
    const b = this.lv.boss;
    if (b && this.arenaActive && !this.bossDead) {
      const bw = 400;
      const bx = W / 2 - bw / 2;
      c.fillStyle = 'rgba(0,0,0,.6)';
      c.fillRect(bx - 4, 16, bw + 8, 26);
      c.fillStyle = '#400';
      c.fillRect(bx, 20, bw, 18);
      c.fillStyle = '#e63946';
      c.fillRect(bx, 20, (bw * Math.max(0, b.hp)) / b.maxHp, 18);
      text(c, 'УНИТАЗИЛЛА, КОРОЛЬ КРЫС', W / 2, 36, 14, '#fff', '#000', 'center');
    }

    // message
    if (this.msgT > 0) {
      c.globalAlpha = Math.min(1, this.msgT / 20);
      text(c, this.msg, W / 2, H - 40, 22, '#fff', '#000', 'center', W - 60);
      c.globalAlpha = 1;
    }

    // intro banner
    if (this.introT > 0) {
      const a = Math.min(1, this.introT / 30, (170 - this.introT) / 20);
      c.globalAlpha = Math.max(0, a);
      text(c, this.lv.name, W / 2, 190, 56, '#ffd60a', '#000', 'center');
      text(c, this.lv.sub, W / 2, 245, 32, '#fff', '#000', 'center', W - 80);
      c.globalAlpha = 1;
    }
  }

  overlay(c: CanvasRenderingContext2D, a = 0.65) {
    c.fillStyle = `rgba(10,5,20,${a})`;
    c.fillRect(0, 0, W, H);
  }

  blink(c: CanvasRenderingContext2D, s: string, y: number) {
    if (Math.floor(this.frame / 25) % 2 === 0) text(c, s, W / 2, y, 24, '#fff', '#000');
  }

  renderTitle(c: CanvasRenderingContext2D) {
    const cam = (this.frame * 1.6) % 3000;
    this.camX = cam;
    const lv = this.lv;
    drawBackground(c, 'dump', cam, this.frame);
    for (const g of lv.grounds) drawGround(c, 'dump', g.x, g.w, cam);
    c.save();
    c.translate(-cam, 0);
    for (const pl of lv.plats) drawPlat(c, 'dump', pl.x, pl.y, pl.w);
    c.restore();
    c.fillStyle = 'rgba(10,5,20,.35)';
    c.fillRect(0, 0, W, H);

    const wob = Math.sin(this.frame * 0.05) * 3;
    c.save();
    c.translate(W / 2, 0);
    c.rotate(Math.sin(this.frame * 0.03) * 0.015);
    text(c, 'ДЕНЧИК,', 0, 92 + wob, 82, '#9bff3d', '#1b3d00', 'center', 520);
    text(c, 'ЧИКЕТКА', 0, 170 - wob, 82, '#ffe14d', '#5a3a00', 'center', 520);
    text(c, 'и ЛУННЫЙ КАМЕНЬ', 0, 235 + wob, 56, '#9fd8ff', '#12306b', 'center', 620);
    c.restore();

    // actors
    drawDenchik(c, 150, GY - 52, 1, 3, 0, true, this.frame, false);
    drawChick(c, 800, GY - 30, 1.5, this.frame, true);
    drawMoonStone(c, 700, GY - 70, 1, this.frame);

    text(c, 'ТРЕШ-ПЛАТФОРМЕР ПРО СОПЛИ, ФАСОЛЬ И ЛЮБОВЬ', W / 2, 285, 20, '#fff', '#000', 'center', W - 100);

    c.fillStyle = 'rgba(0,0,0,.55)';
    c.beginPath();
    c.roundRect(W / 2 - 300, 305, 600, 78, 12);
    c.fill();
    c.font = 'bold 16px sans-serif';
    c.fillStyle = '#fff';
    c.textAlign = 'center';
    c.fillText('← → / A D — бежать     ПРОБЕЛ / ↑ / W — прыжок', W / 2, 335);
    c.fillText('X / J — стрелять соплями     Z / K — ПУКНУТЬ (даёт двойной прыжок!)', W / 2, 360);
    this.blink(c, 'ENTER / ТАП — НАЧАТЬ', 430);
    c.font = '12px sans-serif';
    c.fillStyle = 'rgba(255,255,255,.7)';
    c.fillText('M — звук вкл/выкл', W / 2, 520);
  }

  renderStory(c: CanvasRenderingContext2D) {
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#02030a');
    g.addColorStop(1, '#1d0f44');
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    drawBackground(c, 'moon', 0, this.frame);
    this.overlay(c, 0.5);
    drawMoonStone(c, W / 2, 110, 1.4, this.frame);
    text(c, 'ПРОЛОГ', W / 2, 190, 36, '#ffd60a');
    const lines = [
      'Жил-был Денчик. Обычный парень: нос большой, душа широкая, трусы поверх штанов.',
      'И была у него Чикетка — самая красивая курица-красавица на районе.',
      'Но однажды Король Крыс УНИТАЗИЛЛА спёр ЛУННЫЙ КАМЕНЬ',
      'и утащил Чикетку в своё логово!',
      'Денчик вздохнул, высморкался... и пошёл за любимой.',
      'Оружие: сопли. Спецприём: фасоль. Мотивация: любовь (и шаурма).',
    ];
    const shown = Math.min(lines.length, 1 + Math.floor(this.stateT / 60));
    for (let i = 0; i < shown; i++) {
      c.globalAlpha = Math.min(1, (this.stateT - i * 60) / 30);
      text(c, lines[i], W / 2, 235 + i * 36, 19, '#fff', '#000', 'center', W - 60);
    }
    c.globalAlpha = 1;
    drawChick(c, 120, 400, 1.6, this.frame);
    drawDenchik(c, 800, 380, -1, 0, 0, true, this.frame, false);
    this.blink(c, 'ENTER / ТАП — ПОГНАЛИ!', 500);
  }

  renderClear(c: CanvasRenderingContext2D) {
    this.overlay(c, 0.7);
    text(c, 'УРОВЕНЬ ПРОЙДЕН!', W / 2, 110, 60, '#9bff3d', '#1b3d00');
    text(c, `Очки: ${this.score}   Семечек: ${this.seeds}`, W / 2, 160, 28, '#ffd60a');
    const lines = this.lv.outro;
    lines.forEach((l, i) => text(c, l, W / 2, 230 + i * 44, 22, '#fff', '#000', 'center', W - 60));
    drawDenchik(c, W / 2 - 14, 370, 1, 0, 0, true, this.frame, false);
    this.blink(c, 'ENTER / ТАП — ДАЛЬШЕ', 500);
  }

  renderGameOver(c: CanvasRenderingContext2D) {
    this.overlay(c, 0.75);
    text(c, 'ТЫ СЛИЛСЯ В УНИТАЗ', W / 2, 190, 68, '#e63946', '#000', 'center', W - 60);
    text(c, 'Чикетка плачет, крысы ржут.', W / 2, 250, 28, '#fff');
    text(c, `Твой счёт: ${this.score}`, W / 2, 300, 30, '#ffd60a');
    if (this.stateT > 60) this.blink(c, 'ENTER / ТАП — ПОПРОБОВАТЬ СНОВА', 400);
  }

  renderWin(c: CanvasRenderingContext2D) {
    this.overlay(c, 0.55);
    for (let i = 0; i < 12; i++) {
      const hx = ((i * 97 + this.frame * (0.6 + (i % 3) * 0.3)) % (W + 60)) - 30;
      const hy = H - ((this.frame * (0.8 + (i % 4) * 0.4) + i * 61) % (H + 40));
      heart(c, hx, hy, 24 + (i % 3) * 8, i % 2 ? '#ff4d8d' : '#ff758f');
    }
    text(c, 'ПОБЕДА!!!', W / 2, 100, 84, '#ffd60a', '#6a1b00', 'center', W - 80);
    drawMoonStone(c, W / 2, 200, 1.8, this.frame);
    drawDenchik(c, W / 2 - 90, 290, 1, 0, 0, true, this.frame, false);
    drawChick(c, W / 2 + 80, 330, 1.7, this.frame, true);
    text(c, 'Денчик вернул Лунный камень и спас Чикетку!', W / 2, 410, 26, '#fff', '#000', 'center', W - 60);
    text(c, `Счёт: ${this.score}  •  Семечек: ${this.seeds}  •  Нос чист (почти)`, W / 2, 446, 20, '#9bff3d', '#000', 'center', W - 60);
    if (this.stateT > 60) this.blink(c, 'ENTER / ТАП — В МЕНЮ', 500);
  }
}

