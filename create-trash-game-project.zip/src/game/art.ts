import { GY, H, W } from './levels';
import type { Enemy, Item, Theme } from './levels';

type C = CanvasRenderingContext2D;

export function hash(n: number) {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
}

export function text(
  c: C,
  s: string,
  x: number,
  y: number,
  size: number,
  fill = '#fff',
  stroke = '#000',
  align: CanvasTextAlign = 'center',
  maxW?: number,
) {
  c.font = `900 ${size}px Impact, 'Arial Black', sans-serif`;
  c.textAlign = align;
  c.lineJoin = 'round';
  c.lineWidth = Math.max(3, size / 6);
  c.strokeStyle = stroke;
  if (maxW) c.strokeText(s, x, y, maxW);
  else c.strokeText(s, x, y);
  c.fillStyle = fill;
  if (maxW) c.fillText(s, x, y, maxW);
  else c.fillText(s, x, y);
}

export function heart(c: C, x: number, y: number, s: number, col: string) {
  c.fillStyle = col;
  c.beginPath();
  c.moveTo(x, y + s * 0.3);
  c.bezierCurveTo(x, y - s * 0.2, x - s * 0.5, y - s * 0.2, x - s * 0.5, y + s * 0.15);
  c.bezierCurveTo(x - s * 0.5, y + s * 0.5, x, y + s * 0.7, x, y + s * 0.95);
  c.bezierCurveTo(x, y + s * 0.7, x + s * 0.5, y + s * 0.5, x + s * 0.5, y + s * 0.15);
  c.bezierCurveTo(x + s * 0.5, y - s * 0.2, x, y - s * 0.2, x, y + s * 0.3);
  c.fill();
}

function circle(c: C, x: number, y: number, r: number, col: string) {
  c.fillStyle = col;
  c.beginPath();
  c.arc(x, y, r, 0, Math.PI * 2);
  c.fill();
}

function ell(c: C, x: number, y: number, rx: number, ry: number, col: string, rot = 0) {
  c.fillStyle = col;
  c.beginPath();
  c.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2);
  c.fill();
}

/* ---------------- Денчик ---------------- */
export function drawDenchik(
  c: C,
  x: number,
  y: number,
  dir: number,
  vx: number,
  vy: number,
  onGround: boolean,
  frame: number,
  shooting: boolean,
) {
  c.save();
  c.translate(x + 14, y);
  if (dir < 0) c.scale(-1, 1);
  const run = Math.abs(vx) > 0.6 && onGround;
  const leg = run ? Math.sin(frame * 0.38) * 8 : 0;
  const wob = Math.sin(frame * 0.2) * 3;
  const air = onGround ? 0 : -vy * 1.2;
  const sp = Math.min(6, Math.abs(vx));

  // cape (полотенце)
  c.fillStyle = '#d62828';
  c.beginPath();
  c.moveTo(-6, 16);
  c.quadraticCurveTo(-18 - sp * 2, 20 + wob + air, -28 - sp * 3.5, 40 + wob * 2 + air);
  c.lineTo(-20 - sp * 2, 46 + wob + air);
  c.lineTo(-14 - sp, 40 + wob * 1.5 + air);
  c.lineTo(-8, 44);
  c.lineTo(-4, 38);
  c.closePath();
  c.fill();
  c.fillStyle = '#ffd60a';
  c.fillRect(-20 - sp * 2, 36 + wob, 8, 3);

  // legs
  const lg = (lx: number, ph: number) => {
    c.fillStyle = '#2a9d2a';
    c.fillRect(lx + ph, 38, 8, 10);
    c.fillStyle = '#5a3a1a';
    c.beginPath();
    c.roundRect(lx + ph - 1, 46, 13, 7, 3);
    c.fill();
  };
  if (onGround) {
    lg(-9, leg);
    lg(2, -leg);
  } else {
    lg(-9, 3);
    lg(2, -3);
  }

  // body
  c.fillStyle = '#38b438';
  c.beginPath();
  c.roundRect(-10, 16, 21, 25, 5);
  c.fill();
  // трусы поверх
  c.fillStyle = '#f4f1de';
  c.beginPath();
  c.roundRect(-10, 32, 21, 10, 3);
  c.fill();
  circle(c, 0, 37, 2.5, '#e63946');
  // belt
  c.fillStyle = '#ffd60a';
  c.fillRect(-10, 29, 21, 3);
  // arm
  c.fillStyle = '#38b438';
  if (shooting) c.fillRect(2, 20, 17, 6);
  else c.fillRect(2, 21 + (run ? Math.sin(frame * 0.38) * 2 : 0), 8, 6);
  circle(c, shooting ? 20 : 11, shooting ? 23 : 24, 3.5, '#f4c28f');

  // head
  circle(c, 2, 8, 12, '#f4c28f');
  // hair
  c.fillStyle = '#5a3a1a';
  c.beginPath();
  c.moveTo(-10, 6);
  c.lineTo(-9, -6);
  c.lineTo(-4, -1);
  c.lineTo(-2, -9);
  c.lineTo(3, -2);
  c.lineTo(8, -8);
  c.lineTo(10, 0);
  c.lineTo(10, 3);
  c.closePath();
  c.fill();
  // eye
  circle(c, 7, 6, 4, '#fff');
  circle(c, 8.5, 6, 2, '#111');
  c.strokeStyle = '#111';
  c.lineWidth = 1.5;
  c.beginPath();
  c.moveTo(3, 1);
  c.lineTo(11, 3.5);
  c.stroke();
  // nose
  circle(c, 14, 11, 6.5, '#ff8fa3');
  circle(c, 16, 12, 1.6, '#a4133c');
  // snot
  c.fillStyle = '#9bff3d';
  const drip = 4 + (Math.sin(frame * 0.1) + 1) * 3;
  c.fillRect(14.5, 13, 3, drip);
  circle(c, 16, 14 + drip, 2.4, '#9bff3d');
  // mouth
  c.strokeStyle = '#7a2a2a';
  c.lineWidth = 1.5;
  c.beginPath();
  c.arc(5, 16, 3, 0.1, Math.PI - 0.3);
  c.stroke();
  c.restore();
}

/* ---------------- Чикетка ---------------- */
export function drawChick(c: C, x: number, y: number, s: number, t: number, flip = false) {
  c.save();
  c.translate(x, y);
  c.scale(flip ? -s : s, s);
  const bob = Math.sin(t * 0.1) * 2;
  c.translate(0, bob);
  // legs
  c.strokeStyle = '#f77f00';
  c.lineWidth = 3;
  c.beginPath();
  c.moveTo(-6, 16);
  c.lineTo(-6, 26);
  c.moveTo(6, 16);
  c.lineTo(6, 26);
  c.moveTo(-10, 27);
  c.lineTo(-2, 27);
  c.moveTo(2, 27);
  c.lineTo(10, 27);
  c.stroke();
  // body
  ell(c, 0, 0, 20, 18, '#ffe14d');
  // wing
  ell(c, -5, 3, 9, 7, '#ffc800', Math.sin(t * 0.2) * 0.4 - 0.3);
  // head
  circle(c, 9, -18, 13, '#ffe14d');
  // tuft
  circle(c, 6, -31, 3.5, '#ffe14d');
  circle(c, 11, -32, 3, '#ffe14d');
  // beak
  c.fillStyle = '#f77f00';
  c.beginPath();
  c.moveTo(20, -20);
  c.lineTo(30, -16);
  c.lineTo(20, -13);
  c.closePath();
  c.fill();
  // eye + lashes
  circle(c, 14, -21, 3, '#111');
  circle(c, 15, -22, 1, '#fff');
  c.strokeStyle = '#111';
  c.lineWidth = 1.5;
  c.beginPath();
  c.moveTo(16, -24);
  c.lineTo(20, -27);
  c.moveTo(13, -25);
  c.lineTo(15, -29);
  c.stroke();
  // blush
  circle(c, 10, -14, 3, 'rgba(255,90,120,.6)');
  // bow
  c.fillStyle = '#ff4d8d';
  c.beginPath();
  c.moveTo(0, -29);
  c.lineTo(-10, -36);
  c.lineTo(-10, -22);
  c.closePath();
  c.fill();
  c.beginPath();
  c.moveTo(0, -29);
  c.lineTo(10, -36);
  c.lineTo(10, -22);
  c.closePath();
  c.fill();
  circle(c, 0, -29, 3, '#c9184a');
  c.restore();
}

/* ---------------- Лунный камень ---------------- */
export function drawMoonStone(c: C, x: number, y: number, s: number, t: number) {
  c.save();
  c.translate(x, y + Math.sin(t * 0.06) * 4);
  const g = c.createRadialGradient(0, 0, 4, 0, 0, 60 * s);
  g.addColorStop(0, 'rgba(160,220,255,.85)');
  g.addColorStop(1, 'rgba(160,220,255,0)');
  c.fillStyle = g;
  c.fillRect(-70 * s, -70 * s, 140 * s, 140 * s);
  c.scale(s, s);
  const gem = c.createLinearGradient(-20, -26, 20, 26);
  gem.addColorStop(0, '#ffffff');
  gem.addColorStop(0.4, '#9fd8ff');
  gem.addColorStop(1, '#4a7bd6');
  c.fillStyle = gem;
  c.strokeStyle = '#1d3b8a';
  c.lineWidth = 2;
  c.beginPath();
  c.moveTo(0, -28);
  c.lineTo(22, -10);
  c.lineTo(16, 20);
  c.lineTo(0, 28);
  c.lineTo(-16, 20);
  c.lineTo(-22, -10);
  c.closePath();
  c.fill();
  c.stroke();
  c.strokeStyle = 'rgba(255,255,255,.8)';
  c.beginPath();
  c.moveTo(-22, -10);
  c.lineTo(0, 0);
  c.lineTo(22, -10);
  c.moveTo(0, 0);
  c.lineTo(0, 28);
  c.stroke();
  // sparkle
  const sp = (Math.sin(t * 0.15) + 1) / 2;
  c.fillStyle = '#fff';
  c.beginPath();
  c.moveTo(-8, -14 - 6 * sp);
  c.lineTo(-6, -14);
  c.lineTo(-8, -14 + 6 * sp);
  c.lineTo(-10, -14);
  c.closePath();
  c.fill();
  c.restore();
}

/* ---------------- Враги ---------------- */
export function drawEnemy(c: C, e: Enemy, frame: number, px: number) {
  c.save();
  const cx = e.x + e.w / 2;
  if (e.kind === 'rat') {
    c.translate(cx, e.y + e.h);
    if (e.dir > 0) c.scale(-1, 1);
    const l = Math.sin((frame + e.t) * 0.4) * 3;
    // tail
    c.strokeStyle = '#ff9bb0';
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(14, -10);
    c.quadraticCurveTo(26, -22 + l, 30, -8 - l);
    c.stroke();
    // legs
    c.fillStyle = '#4a4a55';
    c.fillRect(-10 + l, -5, 4, 5);
    c.fillRect(6 - l, -5, 4, 5);
    ell(c, 0, -11, 17, 10, e.flash > 0 ? '#fff' : '#7d7d8c');
    // head
    ell(c, -15, -11, 8, 7, e.flash > 0 ? '#fff' : '#8a8a9a');
    circle(c, -12, -19, 4, '#ff9bb0');
    circle(c, -21, -11, 2, '#ff9bb0');
    circle(c, -16, -13, 2.2, '#e00');
    circle(c, -16, -13, 0.8, '#000');
    c.fillStyle = '#fff';
    c.fillRect(-21, -8, 2, 3);
    c.fillRect(-18, -8, 2, 3);
    c.strokeStyle = '#ccc';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-22, -12);
    c.lineTo(-30, -15);
    c.moveTo(-22, -10);
    c.lineTo(-30, -9);
    c.stroke();
  } else if (e.kind === 'fly') {
    c.translate(cx, e.y + e.h / 2);
    if (px > cx) c.scale(-1, 1);
    const fl = Math.sin((frame + e.t) * 0.9);
    c.fillStyle = 'rgba(200,240,255,.7)';
    c.strokeStyle = 'rgba(80,120,140,.8)';
    c.lineWidth = 1;
    for (const s of [-1, 1]) {
      c.beginPath();
      c.ellipse(2 + s * 3, -11, 6, 11 * (0.4 + Math.abs(fl) * 0.6), s * 0.5, 0, Math.PI * 2);
      c.fill();
      c.stroke();
    }
    ell(c, 0, 2, 12, 9, e.flash > 0 ? '#fff' : '#2f3d2a');
    c.fillStyle = '#556b2f';
    c.fillRect(-4, -4, 3, 12);
    c.fillRect(2, -4, 3, 12);
    circle(c, -9, 0, 7, e.flash > 0 ? '#fff' : '#3d5236');
    circle(c, -11, -3, 4, '#e00');
    circle(c, -7, -3, 3.5, '#e00');
    c.strokeStyle = '#111';
    c.lineWidth = 1.5;
    c.beginPath();
    c.moveTo(-5, 9);
    c.lineTo(-7, 14);
    c.moveTo(3, 10);
    c.lineTo(4, 15);
    c.stroke();
  } else if (e.kind === 'bin') {
    c.translate(e.x, e.y);
    const sq = e.onGround ? 1 : 1.08;
    const flash = e.flash > 0;
    c.fillStyle = flash ? '#fff' : '#6c7a7a';
    c.beginPath();
    c.moveTo(3, 10);
    c.lineTo(41, 10);
    c.lineTo(37, 52);
    c.lineTo(7, 52);
    c.closePath();
    c.fill();
    c.strokeStyle = '#4a5656';
    c.lineWidth = 2;
    for (let k = 0; k < 4; k++) {
      c.beginPath();
      c.moveTo(12 + k * 7, 14);
      c.lineTo(12 + k * 6, 50);
      c.stroke();
    }
    // lid
    const lid = Math.sin((frame + e.t) * 0.15) * 3 * sq;
    c.fillStyle = flash ? '#fff' : '#8a9a9a';
    c.beginPath();
    c.roundRect(-2, 2 - lid, 48, 9, 3);
    c.fill();
    circle(c, 22, -1 - lid, 4, '#8a9a9a');
    // ooze
    c.fillStyle = '#9bff3d';
    c.fillRect(8, 10, 4, 8 + Math.sin(frame * 0.1 + e.t) * 3);
    c.fillRect(30, 10, 4, 5);
    // face
    circle(c, 15, 26, 5, '#ffe14d');
    circle(c, 29, 26, 5, '#ffe14d');
    const look = px > cx ? 1 : -1;
    circle(c, 15 + look, 27, 2, '#000');
    circle(c, 29 + look, 27, 2, '#000');
    c.strokeStyle = '#000';
    c.lineWidth = 2.5;
    c.beginPath();
    c.moveTo(9, 18);
    c.lineTo(19, 22);
    c.moveTo(35, 18);
    c.lineTo(25, 22);
    c.stroke();
    c.fillStyle = '#300';
    c.beginPath();
    c.moveTo(11, 38);
    for (let k = 0; k < 6; k++) c.lineTo(11 + k * 4.4, k % 2 ? 38 : 45);
    c.lineTo(33, 38);
    c.closePath();
    c.fill();
  } else {
    drawBoss(c, e, frame, px);
  }
  c.restore();
}

function drawBoss(c: C, e: Enemy, frame: number, px: number) {
  c.translate(e.x, e.y);
  const flash = e.flash > 0;
  const hurt = e.hp < e.maxHp / 2;
  const white = flash ? '#ffd0d0' : '#f1f3f5';
  const shade = flash ? '#ffa0a0' : '#ced4da';
  const sq = Math.sin(frame * 0.2) * 2;
  // feet
  c.fillStyle = shade;
  c.fillRect(22, 112, 30, 18);
  c.fillRect(68, 112, 30, 18);
  // base
  c.fillStyle = white;
  c.beginPath();
  c.roundRect(30, 70, 60, 46, 8);
  c.fill();
  // tank
  c.fillStyle = white;
  c.strokeStyle = '#868e96';
  c.lineWidth = 3;
  c.beginPath();
  c.roundRect(14, 0 + sq, 92, 52, 8);
  c.fill();
  c.stroke();
  // handle
  c.fillStyle = '#ffd43b';
  c.fillRect(100, 8 + sq, 18, 6);
  circle(c, 119, 11 + sq, 4, '#ffd43b');
  // crown
  c.fillStyle = '#ffd43b';
  c.beginPath();
  c.moveTo(34, 2 + sq);
  c.lineTo(34, -16 + sq);
  c.lineTo(46, -6 + sq);
  c.lineTo(60, -22 + sq);
  c.lineTo(74, -6 + sq);
  c.lineTo(86, -16 + sq);
  c.lineTo(86, 2 + sq);
  c.closePath();
  c.fill();
  c.strokeStyle = '#b8860b';
  c.lineWidth = 2;
  c.stroke();
  circle(c, 60, -10 + sq, 3, '#e63946');
  // eyes
  const look = px > e.x + 60 ? 3 : -3;
  for (const ex of [40, 80]) {
    circle(c, ex, 24 + sq, 11, '#fff');
    circle(c, ex + look, 26 + sq, 5, hurt ? '#e00' : '#222');
  }
  c.strokeStyle = '#111';
  c.lineWidth = 5;
  c.beginPath();
  c.moveTo(26, 10 + sq);
  c.lineTo(50, 20 + sq);
  c.moveTo(94, 10 + sq);
  c.lineTo(70, 20 + sq);
  c.stroke();
  // bowl / mouth
  c.fillStyle = white;
  c.strokeStyle = '#868e96';
  c.lineWidth = 3;
  c.beginPath();
  c.ellipse(60, 62, 62, 20, 0, 0, Math.PI * 2);
  c.fill();
  c.stroke();
  const open = 6 + (Math.sin(frame * 0.12) + 1) * 3 + (hurt ? 4 : 0);
  c.fillStyle = '#3b1f0e';
  c.beginPath();
  c.ellipse(60, 62, 48, open, 0, 0, Math.PI * 2);
  c.fill();
  c.fillStyle = '#7a4a1a';
  c.beginPath();
  c.ellipse(60, 63 + open * 0.3, 34, open * 0.5, 0, 0, Math.PI * 2);
  c.fill();
  // teeth
  c.fillStyle = '#fff';
  for (let k = 0; k < 7; k++) {
    const tx = 20 + k * 13;
    c.beginPath();
    c.moveTo(tx, 62 - open * 0.9);
    c.lineTo(tx + 6, 62 - open * 0.9);
    c.lineTo(tx + 3, 62 - open * 0.9 + 7);
    c.closePath();
    c.fill();
  }
  // gunk bubbles
  circle(c, 40 + Math.sin(frame * 0.1) * 6, 60, 3, '#9bff3d');
  circle(c, 80 + Math.cos(frame * 0.13) * 6, 62, 4, '#9bff3d');
  if (flash) {
    c.fillStyle = 'rgba(255,0,0,.25)';
    c.fillRect(0, 0, 120, 130);
  }
}

/* ---------------- Предметы ---------------- */
export function drawItem(c: C, it: Item, frame: number) {
  const bob = Math.sin((frame + it.t) * 0.08) * 3;
  c.save();
  c.translate(it.x + 10, it.y + 10 + bob);
  if (it.kind === 'seed') {
    c.rotate(Math.sin((frame + it.t) * 0.05) * 0.4 + 0.5);
    ell(c, 0, 0, 7, 4.5, '#2b2b2b');
    c.strokeStyle = '#eee';
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(-5, 0);
    c.lineTo(5, 0);
    c.stroke();
  } else if (it.kind === 'shawarma') {
    c.rotate(-0.4);
    c.fillStyle = '#6aa84f';
    c.beginPath();
    c.arc(0, -8, 6, Math.PI, 0);
    c.fill();
    c.fillStyle = '#f1d9a0';
    c.beginPath();
    c.roundRect(-8, -8, 16, 22, 4);
    c.fill();
    c.fillStyle = '#c0392b';
    c.fillRect(-8, -2, 16, 3);
    c.fillStyle = '#8d5524';
    c.fillRect(-8, 4, 16, 3);
    c.strokeStyle = '#ffd60a';
    c.lineWidth = 2;
    c.strokeRect(-9, -9, 18, 24);
    // glow
    c.strokeStyle = 'rgba(255,255,100,.5)';
    c.beginPath();
    c.arc(0, 2, 17, 0, Math.PI * 2);
    c.stroke();
  } else if (it.kind === 'beans') {
    c.fillStyle = '#d62828';
    c.beginPath();
    c.roundRect(-8, -9, 16, 20, 2);
    c.fill();
    c.fillStyle = '#ccc';
    c.fillRect(-8, -9, 16, 3);
    c.fillRect(-8, 8, 16, 3);
    ell(c, 0, 1, 4, 2.6, '#8b4513');
    ell(c, 2, 5, 2.5, 1.7, '#8b4513');
    c.strokeStyle = 'rgba(155,255,61,.7)';
    c.lineWidth = 2;
    c.beginPath();
    const w = Math.sin(frame * 0.2) * 2;
    c.moveTo(-3, -12);
    c.quadraticCurveTo(-6 + w, -17, -2, -21);
    c.moveTo(4, -12);
    c.quadraticCurveTo(7 - w, -17, 3, -21);
    c.stroke();
  } else {
    circle(c, 0, 3, 8, '#9bff3d');
    c.fillStyle = '#9bff3d';
    c.fillRect(-3, -9, 6, 8);
    c.fillStyle = '#8b5a2b';
    c.fillRect(-4, -12, 8, 4);
    circle(c, -3, 1, 2.5, 'rgba(255,255,255,.7)');
    circle(c, 1, 5, 1.5, '#6bd11a');
  }
  c.restore();
}

/* ---------------- Унитаз-портал ---------------- */
export function drawToilet(c: C, x: number, y: number, t: number) {
  c.save();
  c.translate(x, y);
  // glow
  const g = c.createRadialGradient(32, 40, 5, 32, 40, 80);
  g.addColorStop(0, 'rgba(120,255,120,.55)');
  g.addColorStop(1, 'rgba(120,255,120,0)');
  c.fillStyle = g;
  c.fillRect(-50, -40, 160, 160);
  c.fillStyle = '#f1f3f5';
  c.strokeStyle = '#868e96';
  c.lineWidth = 2;
  c.beginPath();
  c.roundRect(10, 0, 44, 30, 4);
  c.fill();
  c.stroke();
  c.beginPath();
  c.ellipse(32, 36, 32, 11, 0, 0, Math.PI * 2);
  c.fill();
  c.stroke();
  c.fillStyle = '#2b9348';
  c.beginPath();
  c.ellipse(32, 36, 22, 6 + Math.sin(t * 0.1) * 1.5, 0, 0, Math.PI * 2);
  c.fill();
  c.fillStyle = '#f1f3f5';
  c.beginPath();
  c.roundRect(16, 44, 32, 32, 5);
  c.fill();
  c.stroke();
  // arrow
  c.fillStyle = '#ffd60a';
  const a = Math.sin(t * 0.12) * 4;
  c.beginPath();
  c.moveTo(32, -8 + a);
  c.lineTo(22, -22 + a);
  c.lineTo(42, -22 + a);
  c.closePath();
  c.fill();
  c.restore();
}

/* ---------------- Клетка ---------------- */
export function drawCage(c: C, x: number, y: number, open: boolean, t: number) {
  c.save();
  c.translate(x, y);
  // pedestal + stone
  c.fillStyle = '#6c6c80';
  c.fillRect(-90, 80, 60, 40);
  c.fillStyle = '#8a8aa0';
  c.fillRect(-94, 74, 68, 10);
  drawMoonStone(c, -60, 40, 1, t);
  drawChick(c, 55, 90, 1.4, t, true);
  if (!open) {
    c.strokeStyle = '#3d3d3d';
    c.lineWidth = 4;
    for (let k = 0; k <= 5; k++) {
      c.beginPath();
      c.moveTo(k * 20, 0);
      c.lineTo(k * 20, 120);
      c.stroke();
    }
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(100, 0);
    c.moveTo(0, 60);
    c.lineTo(100, 60);
    c.stroke();
    // lock
    c.fillStyle = '#ffd43b';
    c.fillRect(44, 56, 14, 12);
    c.strokeStyle = '#ffd43b';
    c.beginPath();
    c.arc(51, 56, 5, Math.PI, 0);
    c.stroke();
    // speech
    const b = Math.sin(t * 0.15) * 3;
    c.fillStyle = '#fff';
    c.strokeStyle = '#000';
    c.lineWidth = 2;
    c.beginPath();
    c.roundRect(-10, -52 + b, 130, 34, 8);
    c.fill();
    c.stroke();
    c.fillStyle = '#000';
    c.font = 'bold 15px sans-serif';
    c.textAlign = 'center';
    c.fillText('Денчик, спаси!!', 55, -30 + b);
  } else {
    heart(c, 55, 10 + Math.sin(t * 0.1) * 4, 28, '#ff4d8d');
  }
  c.restore();
}

/* ---------------- Фоны ---------------- */
export function drawBackground(c: C, theme: Theme, cam: number, frame: number) {
  if (theme === 'dump') {
    const g = c.createLinearGradient(0, 0, 0, GY);
    g.addColorStop(0, '#2a1a45');
    g.addColorStop(0.55, '#b5533c');
    g.addColorStop(1, '#f0a850');
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    // stinky sun
    circle(c, 720 - cam * 0.02, 300, 70, 'rgba(255,225,120,.9)');
    circle(c, 720 - cam * 0.02, 300, 90, 'rgba(255,225,120,.2)');
    // far panelki
    const tw = 150;
    const off = cam * 0.15;
    for (let i = Math.floor(off / tw); i < Math.floor(off / tw) + W / tw + 2; i++) {
      const bh = 160 + hash(i) * 170;
      const bx = i * tw - off;
      c.fillStyle = '#3a2447';
      c.fillRect(bx, GY - bh, tw - 8, bh + 20);
      for (let wy = GY - bh + 14; wy < GY - 20; wy += 26) {
        for (let wx = 0; wx < 4; wx++) {
          const lit = hash(i * 31 + wy * 0.37 + wx) > 0.6;
          c.fillStyle = lit ? '#ffd166' : '#271633';
          c.fillRect(bx + 10 + wx * 33, wy, 18, 14);
        }
      }
    }
    // near trash heaps
    const tw2 = 230;
    const off2 = cam * 0.45;
    for (let i = Math.floor(off2 / tw2); i < Math.floor(off2 / tw2) + W / tw2 + 2; i++) {
      const bx = i * tw2 - off2;
      const hh = 50 + hash(i * 7) * 60;
      c.fillStyle = '#2a1a1a';
      c.beginPath();
      c.moveTo(bx - 20, GY + 10);
      c.quadraticCurveTo(bx + tw2 / 2, GY - hh * 2, bx + tw2 + 20, GY + 10);
      c.fill();
      for (let k = 0; k < 6; k++) {
        const col = ['#3b6b3b', '#4a4a8a', '#8a5a2a', '#7a2a2a'][Math.floor(hash(i * 13 + k) * 4)];
        circle(c, bx + 40 + hash(i * 3 + k) * (tw2 - 80), GY - hash(i + k * 5) * hh * 0.8, 9 + hash(k + i) * 8, col);
      }
    }
    // flies in distance
    c.fillStyle = 'rgba(0,0,0,.6)';
    for (let k = 0; k < 14; k++) {
      const fx = (hash(k) * W + frame * (0.5 + hash(k + 9)) * 2 - cam * 0.1) % W;
      c.fillRect((fx + W) % W, 100 + hash(k * 3) * 180 + Math.sin(frame * 0.1 + k) * 8, 2, 2);
    }
  } else if (theme === 'sewer') {
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#0b1814');
    g.addColorStop(1, '#1b3a2c');
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    const bw = 64;
    const bhh = 28;
    const off = cam * 0.3;
    for (let row = 0; row * bhh < GY + 60; row++) {
      const shift = row % 2 ? bw / 2 : 0;
      for (let col = Math.floor((off - shift) / bw); col < Math.floor((off - shift) / bw) + W / bw + 2; col++) {
        const bx = col * bw + shift - off;
        const v = hash(row * 91 + col);
        c.fillStyle = `rgb(${24 + v * 14},${52 + v * 22},${42 + v * 14})`;
        c.fillRect(bx + 1, row * bhh + 1, bw - 2, bhh - 2);
        if (v > 0.85) {
          c.fillStyle = 'rgba(120,200,80,.35)';
          c.fillRect(bx + 1, row * bhh + 1, bw - 2, 6);
        }
      }
    }
    // pipes
    const pOff = cam * 0.55;
    c.fillStyle = '#566a60';
    c.fillRect(0, 60, W, 28);
    c.fillStyle = '#7d9488';
    c.fillRect(0, 63, W, 5);
    c.fillStyle = '#3b4a43';
    for (let i = Math.floor(pOff / 220); i < Math.floor(pOff / 220) + W / 220 + 2; i++) {
      const bx = i * 220 - pOff;
      c.fillRect(bx, 54, 14, 40);
      // drip
      if (hash(i) > 0.3) {
        const dy = ((frame * 2 + hash(i) * 300) % 300) * 0.9;
        circle(c, bx + 7, 94 + dy, 3, '#9bff3d');
      }
    }
    // glowing eyes in dark
    for (let k = 0; k < 5; k++) {
      const ex = ((hash(k + 3) * 1400 - cam * 0.35) % 1100 + 1100) % 1100 - 70;
      if (Math.sin(frame * 0.03 + k * 2) > 0.2) {
        circle(c, ex, 250 + hash(k) * 100, 3, '#ff3b3b');
        circle(c, ex + 14, 250 + hash(k) * 100, 3, '#ff3b3b');
      }
    }
  } else {
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#02030a');
    g.addColorStop(1, '#1d0f44');
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    for (let k = 0; k < 110; k++) {
      const sx = (hash(k) * W - cam * 0.03 * (1 + hash(k + 4)) + W * 4) % W;
      const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame * 0.03 + k));
      c.fillStyle = `rgba(255,255,255,${tw})`;
      c.fillRect(sx, hash(k * 7) * 330, hash(k + 1) > 0.9 ? 3 : 2, 2);
    }
    // Earth
    const ex = 190 - cam * 0.03;
    circle(c, ex, 120, 62, '#2f6fd6');
    c.fillStyle = '#3cb043';
    c.beginPath();
    c.ellipse(ex - 14, 106, 20, 28, 0.4, 0, Math.PI * 2);
    c.ellipse(ex + 24, 140, 16, 12, 0, 0, Math.PI * 2);
    c.fill();
    circle(c, ex - 20, 80, 14, 'rgba(255,255,255,.6)');
    // far mountains
    c.fillStyle = '#2a2545';
    c.beginPath();
    c.moveTo(0, GY);
    const off = cam * 0.2;
    for (let x = 0; x <= W; x += 20) {
      const wx = x + off;
      c.lineTo(x, GY - 70 - Math.sin(wx * 0.006) * 50 - Math.sin(wx * 0.017) * 25);
    }
    c.lineTo(W, GY);
    c.fill();
    c.fillStyle = '#3b3560';
    c.beginPath();
    c.moveTo(0, GY);
    const off2 = cam * 0.5;
    for (let x = 0; x <= W; x += 20) {
      const wx = x + off2;
      c.lineTo(x, GY - 25 - Math.sin(wx * 0.012) * 18 - Math.sin(wx * 0.03) * 8);
    }
    c.lineTo(W, GY);
    c.fill();
  }
}

export function drawGround(c: C, theme: Theme, x: number, w: number, cam: number) {
  const top = theme === 'dump' ? '#6b8e23' : theme === 'sewer' ? '#6a7d6a' : '#cfcfe0';
  const body = theme === 'dump' ? '#4a3322' : theme === 'sewer' ? '#38483f' : '#8a8aa0';
  const dot = theme === 'dump' ? '#2e1f14' : theme === 'sewer' ? '#25322b' : '#6a6a85';
  const sx = x - cam;
  if (sx > W || sx + w < 0) return;
  c.fillStyle = body;
  c.fillRect(sx, GY, w, H - GY);
  c.fillStyle = top;
  c.fillRect(sx, GY, w, 12);
  c.fillStyle = dot;
  for (let px = Math.max(0, Math.floor((cam - x) / 36)) * 36; px < w && x + px < cam + W; px += 36) {
    const h = hash((x + px) * 0.1);
    if (theme === 'moon') {
      c.beginPath();
      c.ellipse(sx + px + 10, GY + 30 + h * 40, 12 + h * 10, 5 + h * 3, 0, 0, Math.PI * 2);
      c.fill();
    } else {
      c.fillRect(sx + px + h * 20, GY + 22 + h * 60, 8 + h * 8, 6 + h * 5);
    }
  }
  // flecks of trash on top
  if (theme !== 'moon') {
    for (let px = Math.max(0, Math.floor((cam - x) / 50)) * 50; px < w && x + px < cam + W; px += 50) {
      const h = hash((x + px) * 0.3);
      const col = ['#e63946', '#4895ef', '#ffd60a', '#f1f1f1'][Math.floor(h * 4)];
      c.fillStyle = col;
      c.fillRect(sx + px + h * 30, GY - 2, 6, 4);
    }
  }
  c.fillStyle = 'rgba(0,0,0,.25)';
  c.fillRect(sx, GY + 12, w, 4);
}

export function drawSlime(c: C, theme: Theme, frame: number) {
  const col = theme === 'dump' ? '#7cff3a' : theme === 'sewer' ? '#8a6a2a' : '#8a3aff';
  const dark = theme === 'dump' ? '#4ab81a' : theme === 'sewer' ? '#5a4318' : '#5a1ad0';
  const y = GY + 70;
  c.fillStyle = dark;
  c.fillRect(0, y, W, H - y);
  c.fillStyle = col;
  c.beginPath();
  c.moveTo(0, H);
  for (let x = 0; x <= W; x += 16) c.lineTo(x, y + Math.sin(x * 0.05 + frame * 0.08) * 4);
  c.lineTo(W, H);
  c.fill();
  for (let k = 0; k < 8; k++) {
    const bx = (hash(k) * W + frame * 0.2) % W;
    const by = y + 10 + ((frame * 0.7 + hash(k + 2) * 100) % 50);
    c.strokeStyle = 'rgba(255,255,255,.5)';
    c.lineWidth = 1.5;
    c.beginPath();
    c.arc(bx, by, 3 + hash(k + 8) * 4, 0, Math.PI * 2);
    c.stroke();
  }
}

export function drawPlat(c: C, theme: Theme, x: number, y: number, w: number) {
  const top = theme === 'dump' ? '#8a5a2b' : theme === 'sewer' ? '#7d8a80' : '#b7b7cc';
  const body = theme === 'dump' ? '#5a3a1a' : theme === 'sewer' ? '#4a574e' : '#7d7d99';
  c.fillStyle = body;
  c.fillRect(x, y, w, 14);
  c.fillStyle = top;
  c.fillRect(x, y, w, 5);
  c.fillStyle = 'rgba(0,0,0,.35)';
  for (let px = 10; px < w; px += 26) c.fillRect(x + px, y + 7, 3, 3);
  c.fillStyle = body;
  c.fillRect(x + 8, y + 14, 6, 6);
  c.fillRect(x + w - 14, y + 14, 6, 6);
}

export function drawCrate(c: C, theme: Theme, x: number, y: number, w: number, h: number) {
  if (theme === 'moon') {
    c.fillStyle = '#7d7d99';
    c.beginPath();
    c.moveTo(x, y + h);
    c.lineTo(x + 6, y + 14);
    c.lineTo(x + 22, y);
    c.lineTo(x + w - 8, y + 6);
    c.lineTo(x + w, y + h);
    c.closePath();
    c.fill();
    c.fillStyle = '#a0a0bd';
    c.beginPath();
    c.moveTo(x + 6, y + 14);
    c.lineTo(x + 22, y);
    c.lineTo(x + w - 8, y + 6);
    c.lineTo(x + w - 14, y + 18);
    c.closePath();
    c.fill();
    return;
  }
  c.fillStyle = theme === 'dump' ? '#a0703a' : '#6a5a3a';
  c.fillRect(x, y, w, h);
  c.strokeStyle = '#3a2410';
  c.lineWidth = 3;
  c.strokeRect(x + 1.5, y + 1.5, w - 3, h - 3);
  c.beginPath();
  c.moveTo(x, y);
  c.lineTo(x + w, y + h);
  c.moveTo(x + w, y);
  c.lineTo(x, y + h);
  c.stroke();
  c.fillStyle = '#ffd60a';
  c.font = 'bold 9px sans-serif';
  c.textAlign = 'center';
  c.fillText('ТРЕШ', x + w / 2, y + 8);
}

export function drawPuddle(c: C, x: number, y: number, w: number, frame: number) {
  c.fillStyle = '#6b8e1a';
  c.beginPath();
  c.ellipse(x + w / 2, y + 8, w / 2, 7, 0, 0, Math.PI * 2);
  c.fill();
  c.fillStyle = '#a4d92a';
  c.beginPath();
  c.ellipse(x + w / 2, y + 6, w / 2 - 6, 4, 0, 0, Math.PI * 2);
  c.fill();
  for (let k = 0; k < 3; k++) {
    const t = (frame * 0.05 + k * 0.33) % 1;
    c.strokeStyle = `rgba(155,255,61,${1 - t})`;
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(x + 14 + k * 22, y + 2 - t * 20);
    c.quadraticCurveTo(x + 8 + k * 22, y - 6 - t * 20, x + 14 + k * 22, y - 14 - t * 20);
    c.stroke();
  }
}
