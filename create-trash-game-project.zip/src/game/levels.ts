export const W = 960;
export const H = 540;
export const GY = 440;

export type Rect = { x: number; y: number; w: number; h: number };
export type Theme = 'dump' | 'sewer' | 'moon';
export type EnemyKind = 'rat' | 'fly' | 'bin' | 'boss';
export type ItemKind = 'seed' | 'shawarma' | 'beans' | 'snot';

export interface Ent extends Rect {
  vx: number;
  vy: number;
  onGround: boolean;
}

export interface Enemy extends Ent {
  kind: EnemyKind;
  hp: number;
  maxHp: number;
  dir: number;
  t: number;
  baseX: number;
  baseY: number;
  hitCd: number;
  flash: number;
  dead: boolean;
  score: number;
}

export interface Item {
  x: number;
  y: number;
  w: number;
  h: number;
  kind: ItemKind;
  t: number;
  taken: boolean;
}

export interface Level {
  name: string;
  sub: string;
  theme: Theme;
  width: number;
  grounds: Rect[];
  solids: Rect[];
  plats: Rect[];
  enemies: Enemy[];
  items: Item[];
  puddles: Rect[];
  exit: Rect;
  boss: Enemy | null;
  arenaLeft: number;
  outro: string[];
}

export function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function overlap(a: Rect, b: Rect) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

const CFG: { name: string; sub: string; theme: Theme; width: number; outro: string[] }[] = [
  {
    name: 'УРОВЕНЬ 1',
    sub: 'Помойка за гаражами',
    theme: 'dump',
    width: 5400,
    outro: [
      'Денчик смыл себя в унитаз — и шлёп!',
      'На стенке записка: «Чикетка в канализации, лох! — Король Крыс»',
      'Из-за двери воняет. Значит, мы на верном пути.',
    ],
  },
  {
    name: 'УРОВЕНЬ 2',
    sub: 'Канализация имени Чикатило-Петровича',
    theme: 'sewer',
    width: 6200,
    outro: [
      'Денчик выплыл из труб, как пробка из шампанского.',
      'Новая записка: «Мы на Луне. Лунный камень наш! Хы-хы»',
      'Пришлось пукнуть в космос. Ракета — это он сам.',
    ],
  },
  {
    name: 'УРОВЕНЬ 3',
    sub: 'Лунная свалка',
    theme: 'moon',
    width: 6000,
    outro: [],
  },
];

export const LEVEL_COUNT = CFG.length;

export function mkEnemy(kind: EnemyKind, x: number, y: number): Enemy {
  const defs = {
    rat: { w: 38, h: 22, hp: 1, s: 50 },
    fly: { w: 28, h: 22, hp: 1, s: 70 },
    bin: { w: 44, h: 52, hp: 3, s: 120 },
    boss: { w: 120, h: 130, hp: 45, s: 3000 },
  };
  const d = defs[kind];
  return {
    kind,
    x,
    y,
    w: d.w,
    h: d.h,
    vx: 0,
    vy: 0,
    onGround: false,
    hp: d.hp,
    maxHp: d.hp,
    dir: -1,
    t: Math.floor(Math.random() * 100),
    baseX: x,
    baseY: y,
    hitCd: 0,
    flash: 0,
    dead: false,
    score: d.s,
  };
}

export function buildLevel(i: number): Level {
  const c = CFG[i];
  const r = mulberry32(i * 7919 + 5);
  const grounds: Rect[] = [];
  const solids: Rect[] = [];
  const plats: Rect[] = [];
  const enemies: Enemy[] = [];
  const items: Item[] = [];
  const puddles: Rect[] = [];
  const bossLevel = i === 2;

  const addItem = (kind: ItemKind, x: number, y: number) =>
    items.push({ x, y, w: 20, h: 20, kind, t: Math.floor(r() * 100), taken: false });

  const stopX = c.width - (bossLevel ? 1000 : 700);
  let x = 0;
  let first = true;
  while (x < stopX) {
    let len = first ? 800 : Math.floor(450 + r() * 400);
    const lastSeg = x + len + 170 >= stopX;
    const contentEnd = c.width - (bossLevel ? 950 : 650);
    let to = x + len - 90;
    if (lastSeg) {
      len = c.width - x;
      to = Math.min(x + 800, contentEnd);
    }
    grounds.push({ x, y: GY, w: len, h: 300 });
    const from = x + (first ? 350 : 90);
    const span = Math.max(40, to - from);

    // crate / rock
    if (!first && r() < 0.4) {
      const cx = from + r() * (span - 60);
      solids.push({ x: cx, y: GY - 50, w: 50, h: 50 });
    }

    // seeds row
    if (r() < 0.7) {
      const sx = from + r() * Math.max(10, span - 160);
      for (let k = 0; k < 5; k++) addItem('seed', sx + k * 28, GY - 60 - Math.sin(k * 0.8) * 26);
    }

    // floating platform
    if (r() < 0.65) {
      const pw = 110 + r() * 60;
      const px = from + r() * Math.max(1, span - pw);
      const py = GY - (90 + r() * 25);
      plats.push({ x: px, y: py, w: pw, h: 14 });
      for (let k = 0; k < 3; k++) addItem('seed', px + 20 + k * 30, py - 28);
      if (r() < 0.3) addItem(r() < 0.5 ? 'snot' : 'beans', px + pw / 2 - 10, py - 60);
    }

    // puddles
    if (!first && r() < 0.35) {
      const pu = { x: from + r() * (span - 80), y: GY - 10, w: 72, h: 10 };
      if (!solids.some((s) => overlap({ x: pu.x - 30, y: pu.y - 40, w: pu.w + 60, h: 60 }, s))) puddles.push(pu);
    }

    // enemies
    const n = first ? 0 : 1 + (r() < 0.5 + i * 0.2 ? 1 : 0) + (i >= 1 && r() < 0.4 ? 1 : 0);
    for (let k = 0; k < n; k++) {
      const q = r();
      let kind: EnemyKind;
      if (i === 0) kind = q < 0.6 ? 'rat' : 'fly';
      else if (i === 1) kind = q < 0.35 ? 'rat' : q < 0.65 ? 'fly' : 'bin';
      else kind = q < 0.25 ? 'rat' : q < 0.55 ? 'fly' : 'bin';
      let ex = from + 40 + r() * Math.max(10, span - 80);
      const e = mkEnemy(kind, ex, 0);
      e.y = kind === 'fly' ? GY - 90 - r() * 80 : GY - e.h - 1;
      let tries = 0;
      while (kind !== 'fly' && solids.some((s) => overlap({ x: ex - 20, y: e.y, w: e.w + 40, h: e.h }, s)) && tries < 8) {
        ex += 70;
        tries++;
      }
      if (ex > x + len - 60) continue;
      e.x = ex;
      e.baseX = ex;
      e.dir = r() < 0.5 ? -1 : 1;
      enemies.push(e);
    }

    // pickups
    const ground = (px: number) => px;
    if (!first && r() < 0.25) addItem('shawarma', ground(from + r() * span), GY - 30);
    if (r() < 0.4) addItem('beans', ground(from + r() * span), GY - 30);
    if (r() < 0.45) addItem('snot', ground(from + r() * span), GY - 30);

    if (lastSeg) {
      x += len;
      break;
    }
    x += len;
    const gap = Math.floor(90 + r() * (40 + i * 15));
    if (gap > 110) plats.push({ x: x + gap / 2 - 45, y: GY - 60, w: 90, h: 14 });
    x += gap;
    first = false;
  }

  let boss: Enemy | null = null;
  let arenaLeft = c.width;
  let exit: Rect;
  if (bossLevel) {
    arenaLeft = c.width - 820;
    boss = mkEnemy('boss', c.width - 300, GY - 131);
    enemies.push(boss);
    exit = { x: c.width - 150, y: GY - 120, w: 110, h: 120 };
    for (let k = 0; k < 2; k++) {
      addItem('shawarma', arenaLeft + 120 + k * 260, GY - 30);
      addItem('snot', arenaLeft + 200 + k * 220, GY - 30);
      addItem('beans', arenaLeft + 160 + k * 300, GY - 30);
    }
    plats.push({ x: arenaLeft + 150, y: GY - 110, w: 140, h: 14 });
    plats.push({ x: arenaLeft + 420, y: GY - 150, w: 140, h: 14 });
  } else {
    exit = { x: c.width - 160, y: GY - 76, w: 64, h: 76 };
    addItem('shawarma', c.width - 400, GY - 30);
    addItem('snot', c.width - 330, GY - 30);
  }

  return {
    name: c.name,
    sub: c.sub,
    theme: c.theme,
    width: c.width,
    grounds,
    solids: [...grounds, ...solids],
    plats,
    enemies,
    items,
    puddles,
    exit,
    boss,
    arenaLeft,
    outro: c.outro,
  };
}
