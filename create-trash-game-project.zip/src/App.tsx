import { useEffect, useRef, useState } from 'react';
import { Game } from './game/engine';
import { H, W } from './game/levels';

type Action = 'left' | 'right' | 'jump' | 'shoot' | 'fart';

function TouchBtn({
  game,
  action,
  label,
  className,
}: {
  game: React.MutableRefObject<Game | null>;
  action: Action;
  label: string;
  className?: string;
}) {
  const down = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    game.current?.setHeld(action, true);
  };
  const up = (e: React.PointerEvent) => {
    e.preventDefault();
    game.current?.setHeld(action, false);
  };
  return (
    <button
      onPointerDown={down}
      onPointerUp={up}
      onPointerCancel={up}
      onContextMenu={(e) => e.preventDefault()}
      className={
        'select-none touch-none rounded-full font-black text-white border-4 border-black/60 active:scale-95 active:brightness-125 shadow-lg ' +
        (className ?? '')
      }
    >
      {label}
    </button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const g = new Game(canvasRef.current!);
    gameRef.current = g;
    return () => {
      g.dispose();
      gameRef.current = null;
    };
  }, []);

  const toggleMute = () => {
    const g = gameRef.current;
    if (!g) return;
    g.muted = !g.muted;
    setMuted(g.muted);
  };

  return (
    <div className="min-h-screen bg-[#120a1c] flex flex-col items-center justify-start py-3 px-2 select-none">
      <div className="w-full max-w-[1100px]">
        <div className="flex items-center justify-between mb-2 px-1">
          <h1 className="text-lg sm:text-2xl font-black tracking-wide text-lime-300 drop-shadow-[0_2px_0_#000]">
            💩 Денчик, Чикетка и Лунный камень
          </h1>
          <button
            onClick={toggleMute}
            className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-sm font-bold border border-white/20"
          >
            {muted ? '🔇 Звук выкл' : '🔊 Звук вкл'}
          </button>
        </div>
        <div className="relative rounded-xl overflow-hidden border-4 border-lime-400/70 shadow-[0_0_40px_rgba(155,255,61,.25)]">
          <canvas
            ref={canvasRef}
            width={W}
            height={H}
            className="w-full h-auto block bg-black touch-none"
            style={{ imageRendering: 'auto' }}
            onPointerDown={() => gameRef.current?.tap()}
          />
        </div>

        {/* touch controls */}
        <div className="mt-3 flex justify-between items-end md:hidden touch-none">
          <div className="flex gap-3">
            <TouchBtn game={gameRef} action="left" label="◀" className="w-20 h-20 text-3xl bg-slate-600" />
            <TouchBtn game={gameRef} action="right" label="▶" className="w-20 h-20 text-3xl bg-slate-600" />
          </div>
          <div className="flex gap-2 items-end">
            <TouchBtn game={gameRef} action="fart" label="💨" className="w-16 h-16 text-2xl bg-lime-600" />
            <TouchBtn game={gameRef} action="shoot" label="🤧" className="w-16 h-16 text-2xl bg-emerald-600" />
            <TouchBtn game={gameRef} action="jump" label="⤒" className="w-20 h-20 text-3xl bg-rose-600" />
          </div>
        </div>

        <p className="hidden md:block mt-3 text-center text-sm text-white/60">
          ← → бежать • Пробел — прыжок • X — сопли • Z — пукнуть (в воздухе = двойной прыжок) • M — звук
        </p>
      </div>
    </div>
  );
}
